package com.pocexample.springboot.service;

import java.util.List;

import com.pocexample.springboot.model.User;

public interface UserService {
	Boolean createUser(User user);
	User getUserById(long userId);
}

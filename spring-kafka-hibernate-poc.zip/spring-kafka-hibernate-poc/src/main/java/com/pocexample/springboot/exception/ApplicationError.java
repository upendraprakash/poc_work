package com.pocexample.springboot.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class ApplicationError extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public ApplicationError(String message) {
		super(message);
	}
	
	public ApplicationError(String message, Throwable throwable) {
		super(message, throwable);
	}
}

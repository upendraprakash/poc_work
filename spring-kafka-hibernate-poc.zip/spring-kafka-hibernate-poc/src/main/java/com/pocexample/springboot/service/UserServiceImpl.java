package com.pocexample.springboot.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pocexample.springboot.exception.ApplicationError;
import com.pocexample.springboot.exception.UserAlreadyExistException;
import com.pocexample.springboot.model.User;
import com.pocexample.springboot.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CredsProducer credsProducer;

	@Override
	public Boolean createUser(User user) {
		// TODO Auto-generated method stub
		if(user.getUserName().equals("abc")) {
			throw new UserAlreadyExistException(user.getUserName()+" user already exist.");
		}
		
		ObjectMapper Obj = new ObjectMapper();
		try {
			String credentials = Obj.writeValueAsString(user);
			credsProducer.send(credentials);
			return true;
		} catch (JsonProcessingException e) {
		
		}
		return false;
	}

	@KafkaListener(topics = "CredsTopic", groupId = "test-consumer-group")
	public void listen(String message) {
		ObjectMapper objectMapper=new ObjectMapper();
		System.out.println("Received Messasge in group - group-id: " + message);
		User user;
		try {
			user = objectMapper.readValue(message, User.class);
			userRepository.save(user);
		} catch (IOException e) {
			throw new ApplicationError("Parsing error ",e);
		}
	
	}


	@Override
	public User getUserById(long userId) {
	Optional<User> user=	this.userRepository.findById(userId);
		return user.get();
	}


}

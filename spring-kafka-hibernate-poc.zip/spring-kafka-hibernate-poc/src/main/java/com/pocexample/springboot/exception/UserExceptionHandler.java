package com.pocexample.springboot.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
import com.pocexample.springboot.model.ErrorResponse;

@ControllerAdvice
public class UserExceptionHandler {

	@ExceptionHandler(value = UserAlreadyExistException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ErrorResponse handleCustomerAlreadyExistsException(UserAlreadyExistException ex) {
		return new ErrorResponse(HttpStatus.CONFLICT.value(), ex.getMessage());
	}
	
	@ExceptionHandler(value = ApplicationError.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ErrorResponse handleApplicationError(ApplicationError ex) {
		return new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage());
	}
}

package com.pocexample.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pocexample.springboot.model.User;
import com.pocexample.springboot.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	@GetMapping("/getUserDetails/{id}")
	public ResponseEntity<User> getUser(@PathVariable(name = "id") Long userid){
		User user=userService.getUserById(userid);
		if(user!=null)
		return ResponseEntity.ok().body(user);
		else
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
	
	
	@PostMapping("/createUser")
	public ResponseEntity<String> createUser(@RequestBody User user){
		if(this.userService.createUser(user))
			return ResponseEntity.status(HttpStatus.CREATED).body("data pushe");
		else 
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}

}

package com.pocexample.springboot.controller;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.pocexample.springboot.model.User;
import com.pocexample.springboot.repository.UserRepository;
import com.pocexample.springboot.service.CredsProducer;
import com.pocexample.springboot.service.UserService;
import com.pocexample.springboot.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class UserServiceTest {
	@InjectMocks
	UserServiceImpl userService;

	private CredsProducer credsProducer = Mockito.mock(CredsProducer.class);
	private UserRepository userRepository = Mockito.mock(UserRepository.class);

	@Test
	public void testCreateUser() {
		User user = new User();
		user.setId(1L);
		user.setUserName("mark");
		user.setPassword("Mark@1234");
		Mockito.doNothing().when(credsProducer).send(Mockito.anyString());
		assertTrue(userService.createUser(user));
	}

	@Test
	public void testGetUserById() {
	
		User user = new User();
		user.setId(1L);
		user.setUserName("mark");
		user.setPassword("Mark@1234");
		Mockito.when(userRepository.findById(1L)).thenReturn(Optional.of(user));
		User user2=userService.getUserById(1L);
		assertEquals("mark", user2.getUserName());
		
	}

}

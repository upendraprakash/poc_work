package com.pocexample.springboot.controller;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.pocexample.springboot.model.User;
import com.pocexample.springboot.service.UserService;

import junit.framework.Assert;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class UserControllerTest {

	 @InjectMocks
	 UserController userController;

	private UserService userService=Mockito.mock(UserService.class);

	@Test
	public void createUserTest() {
		User user=new User();
		user.setId(1L);
		user.setUserName("mark");
		user.setPassword("Mark@1234");
		
		Mockito.when(userService.createUser(user)).thenReturn(true);
		ResponseEntity<String> responseEntity= userController.createUser(user);
		Assert.assertNotNull(responseEntity.getBody());
		Assert.assertEquals(true, responseEntity.getBody().equals("data pushe"));
		
	}
	
	
	@Test
	public void testGetUser() throws Exception {
		User user=new User();
		user.setId(1L);
		user.setUserName("mark");
		user.setPassword("Mark@1234");
		
		Mockito.when(userService.getUserById(1L)).thenReturn(user);
		ResponseEntity<User> responseEntity= userController.getUser(1L);
		Assert.assertNotNull(responseEntity.getBody());
		
	}
	
	
}